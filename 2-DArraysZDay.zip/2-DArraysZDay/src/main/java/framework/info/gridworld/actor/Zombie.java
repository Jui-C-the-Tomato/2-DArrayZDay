package main.java.framework.info.gridworld.actor;

public class Zombie {
}
