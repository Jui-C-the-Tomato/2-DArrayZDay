package main.java.projects.zBug;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import main.java.projects.zBug.ZBug;

import java.awt.Color;

/**
 * This class runs a world that contains box bugs. <br />
 * This class is not tested on the AP CS A and AB exams.
 */
public class ZBugRunner
{
    public static void main(String[] args)
    {
        int[] sizes = {2,3,4,5,6};
        int maxSize = sizes.length;

        for(int i = 0; i < maxSize; i++){
            int randSizePos = (int)(Math.random()*maxSize);
            int temporaryValue = sizes[i];
            sizes[i] = sizes[randSizePos];
            sizes[randSizePos] = temporaryValue;
        }


        ActorWorld world = new ActorWorld();
        ZBug harpseal = new ZBug(sizes[0]);
        ZBug seal = new ZBug(sizes[1]);
        seal.setColor(Color.ORANGE);
        ZBug harborseal = new ZBug(sizes[2]);
        harborseal.setColor(Color.YELLOW);
        ZBug obeseseal = new ZBug(sizes[3]);
        obeseseal.setColor(Color.BLACK);
        ZBug handsomeseal = new ZBug(sizes[4]);
        handsomeseal.setColor(Color.BLUE);

        world.add(new Location(randNumber(20), randNumber(20)), seal);
        world.add(new Location(randNumber(20), randNumber(20)), harpseal);
        world.add(new Location(randNumber(20), randNumber(20)), obeseseal);
        world.add(new Location(randNumber(20), randNumber(20)), harborseal);
        world.add(new Location(randNumber(20), randNumber(20)), handsomeseal);
        world.show();
    }
    public static int randNumber(int range){
        int randN = (int)(Math.random()*range)+1;
        return randN;
    }
}