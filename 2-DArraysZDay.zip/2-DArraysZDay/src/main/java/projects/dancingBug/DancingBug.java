package main.java.projects.dancingBug;

/*
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */

import info.gridworld.actor.Bug;

/**
 * A <code>BoxBug</code> traces out a square "box" of a given size. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class DancingBug extends Bug
{
    private int steps;
    private int length;
    private int randNum;
    private boolean firstTurned;
    private boolean secondTurned;
    private boolean allSet;
    private boolean next;

    /**
     * Constructs a box bug that traces a square of a given side length
     * @param //length the side length
     */
    public DancingBug(int givenLength)
    {
        steps = 0;
        length = givenLength;
        randNum = 0;
        firstTurned = false;
        secondTurned = false;
        allSet = false;
        next = false;

    }

    /**
     * Moves to the next location of the square.
     */
    public void act()
    {
        if(!next){
            randNum = (int)(Math.random()*3) +1; //chooses a number between 1 and 3 in order to choose type of shape
            next = true;
        }
        else {
            for(int j = 0; j < 12; j++){ //each chosen shape has 12 repetitions to draw its shape
                switch (randNum) {
                    case 1: //Circle shape Drawer
                        if (steps < length / 3 && canMove()) {
                            move();
                            steps++;
                        } else {
                            turn();
                            steps = 0;
                        }
                        break;
                    case 2: //Z Shape Drawer
                        if (allSet) {
                            if (steps < length && canMove()) {
                                move();
                                steps++;
                            } else {
                                if (!firstTurned) {
                                    for (int i = 0; i < 3; i++) {
                                        turn();
                                    }
                                    firstTurned = true;
                                } else {
                                    if (!secondTurned) {
                                        for (int i = 0; i < 5; i++) {
                                            turn();
                                        }
                                        secondTurned = true;
                                    } else {
                                        for (int i = 0; i < 4; i++) {
                                            turn();
                                        }
                                        secondTurned = false;
                                        firstTurned = false;
                                    }

                                }
                                steps = 0;
                            }
                        } else {
                            turn();
                            turn();
                            allSet = true;
                        }

                        break;
                    case 3: //Box Shape Drawer
                        if (steps < length && canMove()) {
                            move();
                            steps++;
                        } else {
                            turn();
                            turn();
                            steps = 0;
                        }
                        break;
                }
                next = false;
            }
        }
    }
}
