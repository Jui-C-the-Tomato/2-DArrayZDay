package main.java.projects.ZDay;

public class SlowZombie {
}
