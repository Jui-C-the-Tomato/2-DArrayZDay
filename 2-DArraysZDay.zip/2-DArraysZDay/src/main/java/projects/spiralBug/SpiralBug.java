package main.java.projects.spiralBug;

import info.gridworld.actor.Bug;

/**
 * A <code>BoxBug</code> traces out a square "box" of a given size. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class SpiralBug extends Bug
{
    private int steps;
    private int spiralRadius;
    private int timesTurned;
    /**
     * Constructs a box bug that traces a square of a given side length
     * @param //length the side length
     */
    public SpiralBug(int radius)
    {
        steps = 0;
        spiralRadius = radius;
        timesTurned = 8;
    }

    /**
     * Moves to the next location of the square.
     */
    public void act()
    {
        if(timesTurned % 8 != 0) {
            if (steps < spiralRadius / 3 && canMove()) {
                move();
                steps++;
            } else {
                turn();
                timesTurned++;
                steps = 0;
            }
        }else{
            move();
            timesTurned ++;
        }
    }
}

